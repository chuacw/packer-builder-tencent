package tencent

import "testing"

// CheckConfigHasErrors checks that a test has errors
func CheckConfigHasErrors(t *testing.T, warns []string, err error) {
	if len(warns) > 0 {
		t.Fatalf("bad: %#v", warns)
	}
	if err == nil {
		t.Fatal("should error")
	}
}

// CheckConfigIsOk checks that a test has no errors
func CheckConfigIsOk(t *testing.T, warns []string, err error) {
	if len(warns) > 0 {
		t.Fatalf("bad: %#v", warns)
	}
	if err != nil {
		t.Fatalf("bad: %s", err)
	}
}
